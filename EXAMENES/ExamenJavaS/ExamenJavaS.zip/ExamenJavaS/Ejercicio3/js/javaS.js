/*menu */
const colors=()=>{
    menu[0].style.color="blue";
}
const menu=document.getElementsByClassName("color");
   menu.addEventListener("click",colors);






/*botones*/

const colorBoton=()=>{
    boton.style.background="red";
}
const colorBotonS=()=>{
    boton.style.background="pink";
}
const boton=document.getElementsByClassName("btn");
boton.addEventListener("mouseover",colorBoton);
boton.addEventListener("mouseleave",colorBotonS);

/*precios */

const price=document.getElementsByClassName("price")[0];
price.forEach(x=>x.addEventListener("mouseover",()=>{
    x.style = 'font-size ';
}))





