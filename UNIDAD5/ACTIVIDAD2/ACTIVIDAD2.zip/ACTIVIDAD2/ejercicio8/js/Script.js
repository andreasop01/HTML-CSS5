const operacion = (op,op2)=>{
    return op*op2;
}

const factor = valor =>{
    let val=valor;
    

    for(let i=valor-1; i>0; i--){
        val=operacion(val,i);
    } 
    return val;
}
let numero=parseInt(prompt("dame un numero"));
alert(factor (numero));

