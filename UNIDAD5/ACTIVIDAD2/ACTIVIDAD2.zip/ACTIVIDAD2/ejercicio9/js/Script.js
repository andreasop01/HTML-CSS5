
const Teclado = () => prompt("Introducir aqui");

const esNumero = num =>{
    return !isNaN(num);
};

const esPositivo = num =>{
    return num>=0;
}

const p = (op, potencia)=>{
    let poten=op;
    for(let i=2; i<=potencia; i++){
        poten*=num1;
    }
    return poten;
}

let num1;
let num2;

do{
    num1=prompt("dime un numero");
    if (!esNumero(num1)){
        alert("no es un numero");
    }else{
        if(!esPositivo(num1)){
            alert("no numero negativos");
        }
    }
}while(!esNumero(num1) || !esPositivo(num1));

do{
    num2=prompt("dime un numero");
    if (!esNumero(num2)){
        alert("no es un numero");
    }else{
        if(!esPositivo(num2)){
            alert("no numero negativos");
        }
    }
}while(!esNumero(num2) || !esPositivo(num2));

num1=parseInt(num1);
num2=parseInt(num2);

alert(p(num1,num2));
