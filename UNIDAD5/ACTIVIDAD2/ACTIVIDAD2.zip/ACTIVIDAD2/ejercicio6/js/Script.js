
const multiplos=(i)=>{
    if(i%4==0){
        return" (multiplo de 4) "
    }else{
        if(i%9==0){
            return" (multiplo de 9) "
        }
    }
    return "";
}

const saltoLinea=(i)=>{
    if(i%5==0){
        document.write("---------------------"+"<br>")
    }
}


for(i=1; i<=500; i++){
    
    document.write(i+multiplos(i)+"<br>")
    saltoLinea(i);
    
       
}

