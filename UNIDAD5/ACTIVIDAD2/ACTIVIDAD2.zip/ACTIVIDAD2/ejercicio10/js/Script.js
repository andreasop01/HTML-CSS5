const fecha = (dia, mes, año)=>{
    return dia>0 && mes>=1 && mes<=12 && año>0;
};

const excepcion= (dia, mes, año)=>{

    let meses=[31,29,31,30,31,30,31,31,30,31,30,31];
    let nombreMes=["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"];

    if(dia<=meses[mes]){
        alert(dia+" de "+nombreMes[mes]+" de "+año)
       }else{
        alert("no es correcto")
       }
}

let mes=parseInt(prompt("dame mes"));
let dia=parseInt(prompt("dame dia"));
let año=parseInt(prompt("dame año"));

if (fecha (dia,mes,año)){
    mes--;

   excepcion(dia,mes,año);
    
}