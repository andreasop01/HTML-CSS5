const cadenaNumeros=i=>{
    for(b=1;b<=i;b++){
        imprimirNumeros(i);
    }
}
const imprimirNumeros=(i)=>document.write(i);

for(let i=1; i<=30; i++ ){
    cadenaNumeros(i);
    document.write("<br>");
}