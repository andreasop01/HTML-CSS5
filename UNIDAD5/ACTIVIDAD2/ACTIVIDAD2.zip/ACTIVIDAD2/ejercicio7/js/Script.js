var valores = [true, 5, false, "hola", "adios", 2];

const tamaño = cadena =>{
    return cadena.length;
};

const texto = cadena =>{
    return typeof cadena == "string";
};

 let mayor;
 let m=0;

for(c of valores){
    if(texto(c)){
        if(tamaño(c)>m){
            m=tamaño(c);
            mayor=c;
        }
    }
} 
alert(mayor);


//2
const Booleano = bolean =>{
    return typeof bolean == "boolean"
};

for(bule of valores){
    if(Booleano(bule)){
        if(bule){
            alert("es correcto");
        } else{
            alert("es falso");
        }
    }
}

//3

const numero = num =>{
    return typeof num == "number"
};

let op=0;
let op2=0;

for(n of valores){
    if(numero(n)){
       if(op==0){
           op=n;
       } else{
        op=n;
       }
    }
}

alert(op-op2);
alert(op+op2);
alert(op*op2);
alert(op/op2);


















