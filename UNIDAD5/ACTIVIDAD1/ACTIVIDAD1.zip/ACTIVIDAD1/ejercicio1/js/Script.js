/**
 * edad, es la variable para calcular guardar la edad introducida por el usuario
 */

let edad=prompt("dime tu edad");

/**
 * if , la condion que determina si la edad es mayor o igual a 18.
 * else, si la condicion del if no es cierca entra en el else.
 */

if(edad>=18){
    alert("Puedes conducir")
}else{
    alert("No puedes conducir")
}