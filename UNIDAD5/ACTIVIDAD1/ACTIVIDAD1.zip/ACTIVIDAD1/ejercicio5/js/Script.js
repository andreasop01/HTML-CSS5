
/**
 * hacemos el for donde:
 * declaramos la variable i
 * le damos un rango de menor igual a 30
 * y que se repita
 * dentro hago otro for donde:
 * declaro la variable b
 * donde b sea menor igualo a i 
 * se repita
 * y se imprima por pantalla
 */
for(let i=1;i<=30;i++){
    for(let b=1;b<=i;b++){
        
        document.write(i);
    }

    document.write("<br>");

}